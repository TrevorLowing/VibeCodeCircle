=== Plugin Name ===
Contributors: matteogreco,kevingeary
Tags: plugin
Requires at least: 5.9
Tested up to: 6.8.1
Stable tag: 1.0
Requires PHP: 8.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Etch.

== Description ==

Plugin's description.

== Instructions ==

Installation instructions.

== Changelog ==

Changelog.
