=== Etch Theme ===
Contributors: digital-gravy
Tested up to: 6.9
Requires at least: 6.1
Requires PHP: 8.0
Version: 0.0.5
License: GPL v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.txt
Copyright: Digital Gravy

Etch Starter Theme.

== Changelog ==
0.0.1 Initial release
0.0.2 Update to custom etch blocks
0.0.3 Some fixes
0.0.4 Fix unwanted margin on image block
0.0.5 Cleanup and QoL improvements [ETC-228]
